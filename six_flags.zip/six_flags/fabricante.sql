INSERT INTO fabricante (
   nombre
)
VALUES
   ('Hopkins Rides')
   , ('Vekoma')
   , ('Intamin')
   , ('Funtime Austria')
   , ('Chance Morgan')
   , ('Mack Rides')
   , ('Gerstlauer')
   , ('Bolliger & Mabillard')
   , ('Zamperla')
   , ('SBF Visa')
   , ('Huss Park Attractions')
   , ('Rocky Mountain Construction')
   , ('Schwarzkopf')
   , ('Zierer')
   , ('No Info')
;