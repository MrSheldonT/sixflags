INSERT INTO categoria_tienda(
    nombre
)
VALUES 
    ('Dulceria')
    , ('Juguetes')
    , ('Moda')
    , ('Recuerdos');
