INSERT INTO categoria_producto (
   nombre
)
VALUES
   ('Pase de temporada')
   , ('Boleto de un Día')
   , ('Plan de alimentos')
   , ('VIP')
   , ('Grupos')
   , ('Membresía')
   , ('Cabaña')
   , ('Estacionamiento')
   , ('Paquete')
   , ('General')
   , ('Paquete de media digital')
   , ('Transporte')
   , ('Six Flags Plus')
;
