INSERT INTO villa(
     parque_id
     , nombre
)
VALUES 
     (1, 'Villa Hollywood')
     , (1, 'Pueblo Mexicano')
     , (1, 'DC Super Friends')
     , (1, 'Pueblo Francés')
     , (1, 'Bugs Bunny Boomtown')
     , (1, 'Pueblo Vaquero')
     , (1, 'Pueblo Suizo')
     , (1, 'Circo de Bugs Bunny')
     , (1, 'Pueblo Polinesio')
     , (1, 'Pueblo infantil')
     , (2, 'Hurricane Harbor')
;
