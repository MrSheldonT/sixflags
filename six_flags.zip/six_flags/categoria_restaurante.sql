INSERT INTO categoria_restaurante(
    nombre
)
VALUES 
    ('Antojos y Bebidas')
    , ('Café y Demás')
    , ('Comida Americana')
    , ('Comida Baja en Grasa')
    , ('Comida Italiana')
    , ('Comida Mexicana')
    , ('Helados y postres')
;
