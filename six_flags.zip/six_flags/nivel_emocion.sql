INSERT INTO nivel_emocion (
   nombre
)
VALUES 
   ('Maximum')
   , ('Moderate')
   , ('Mild')
;